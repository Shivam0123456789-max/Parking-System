import tkinter as tk
from tkinter import messagebox

root = tk.Tk()
root.title("Smart Parking Management System")
root.geometry("900x780")
root.configure(bg="#eef2f7")

# Parking slot data
parking_slots = []

for i in range(1, 21):
    slot = {
        "id": f"P{i:02d}",
        "distance": i * 2,
        "status": "Available",
        "vehicle": None
    }
    parking_slots.append(slot)

# Main heading
heading = tk.Label(
    root,
    text="SMART PARKING MANAGEMENT SYSTEM",
    font=("Arial", 21, "bold"),
    bg="#eef2f7",
    fg="#1f2937"
)
heading.pack(pady=20)

# Dashboard statistics
stats_frame = tk.Frame(root, bg="#eef2f7")
stats_frame.pack(pady=10)

total_label = tk.Label(
    stats_frame,
    text="Total Slots: 20",
    font=("Arial", 14, "bold"),
    bg="#34495e",
    fg="white",
    width=18,
    height=2
)
total_label.grid(row=0, column=0, padx=10)

available_label = tk.Label(
    stats_frame,
    text="Available: 20",
    font=("Arial", 14, "bold"),
    bg="#27ae60",
    fg="white",
    width=18,
    height=2
)
available_label.grid(row=0, column=1, padx=10)

occupied_label = tk.Label(
    stats_frame,
    text="Occupied: 0",
    font=("Arial", 14, "bold"),
    bg="#e74c3c",
    fg="white",
    width=18,
    height=2
)
occupied_label.grid(row=0, column=2, padx=10)

# Vehicle input
input_frame = tk.Frame(root, bg="#eef2f7")
input_frame.pack(pady=20)

vehicle_label = tk.Label(
    input_frame,
    text="Vehicle Number:",
    font=("Arial", 12),
    bg="#eef2f7"
)
vehicle_label.grid(row=0, column=0, padx=5)

vehicle_entry = tk.Entry(
    input_frame,
    font=("Arial", 12),
    width=22
)
vehicle_entry.grid(row=0, column=1, padx=5)

# Parking slots display
slots_frame = tk.Frame(root, bg="#eef2f7")
slots_frame.pack(pady=15)

# Parking entrance
entrance_label = tk.Label(
    slots_frame,
    text="ENTRANCE ↓",
    font=("Arial", 11, "bold"),
    bg="#eef2f7",
    fg="#2980b9"
)
entrance_label.grid(row=0, column=0, padx=9, pady=5)

slot_labels = {}

def update_display():
    available_count = 0
    occupied_count = 0

    for slot in parking_slots:
        if slot["status"] == "Available":
            color = "#27ae60"
            text = f"{slot['id']}\nAvailable\n{slot['distance']} metres"
            available_count += 1
        else:
            color = "#e74c3c"
            text = f"{slot['id']}\nOccupied\n{slot['distance']} metres"
            occupied_count += 1

        slot_labels[slot["id"]].config(
            text=text,
            bg=color
        )

    available_label.config(
        text=f"Available: {available_count}"
    )

    occupied_label.config(
        text=f"Occupied: {occupied_count}"
    )

def allocate_parking():
    vehicle = vehicle_entry.get().strip().upper()

    if not vehicle:
        messagebox.showwarning("Warning", "Please enter a vehicle number.")
        return

    for slot in parking_slots:
        if slot["vehicle"] == vehicle:
            messagebox.showinfo(
                "Already Parked",
                f"This vehicle is already parked in {slot['id']}."
            )
            return

    available_slots = [
        slot for slot in parking_slots
        if slot["status"] == "Available"
    ]

    if not available_slots:
        messagebox.showerror("Full", "No parking slots are available.")
        return

    # Greedy Algorithm
    nearest_slot = min(
        available_slots,
        key=lambda slot: slot["distance"]
    )

    nearest_slot["status"] = "Occupied"
    nearest_slot["vehicle"] = vehicle

    update_display()

    messagebox.showinfo(
        "Parking Allocated",
        f"Vehicle {vehicle} assigned to {nearest_slot['id']}."
    )

    vehicle_entry.delete(0, tk.END)

def release_parking():
    vehicle = vehicle_entry.get().strip().upper()

    if not vehicle:
        messagebox.showwarning("Warning", "Please enter a vehicle number.")
        return

    for slot in parking_slots:
        if slot["vehicle"] == vehicle:
            released_slot = slot["id"]

            slot["status"] = "Available"
            slot["vehicle"] = None

            update_display()

            messagebox.showinfo(
                "Parking Released",
                f"Parking slot {released_slot} is now available."
            )

            vehicle_entry.delete(0, tk.END)
            return

    messagebox.showerror(
        "Not Found",
        "This vehicle is not currently parked."
    )

def search_vehicle():
    vehicle = vehicle_entry.get().strip().upper()

    if not vehicle:
        messagebox.showwarning("Warning", "Please enter a vehicle number.")
        return

    for slot in parking_slots:
        if slot["vehicle"] == vehicle:
            messagebox.showinfo(
                "Vehicle Found",
                f"Vehicle: {vehicle}\n"
                f"Parking Slot: {slot['id']}\n"
                f"Distance: {slot['distance']} metres"
            )
            return

    messagebox.showerror(
        "Not Found",
        "This vehicle is not currently parked."
    )

# Create parking slot labels
for index, slot in enumerate(parking_slots):
    label = tk.Label(
        slots_frame,
        text=f"{slot['id']}\nAvailable\n{slot['distance']} m",
        width=13,
        height=4,
        bg="#27ae60",
        fg="white",
        font=("Arial", 11, "bold"),
        relief="raised",
        borderwidth=2
    )

    label.grid(
        row=index // 5 + 1,
        column=index % 5,
        padx=9,
        pady=9
    )

    slot_labels[slot["id"]] = label

# Buttons
button_frame = tk.Frame(root, bg="#eef2f7")
button_frame.pack(pady=15)

allocate_button = tk.Button(
    button_frame,
    text="Allocate Parking",
    font=("Arial", 11, "bold"),
    bg="#2980b9",
    fg="white",
    width=16,
    command=allocate_parking
)
allocate_button.grid(row=0, column=0, padx=8)

release_button = tk.Button(
    button_frame,
    text="Release Parking",
    font=("Arial", 11, "bold"),
    bg="#e67e22",
    fg="white",
    width=16,
    command=release_parking
)
release_button.grid(row=0, column=1, padx=8)

search_button = tk.Button(
    button_frame,
    text="Search Vehicle",
    font=("Arial", 11, "bold"),
    bg="#8e44ad",
    fg="white",
    width=16,
    command=search_vehicle
)
search_button.grid(row=0, column=2, padx=8)

# Colour legend
legend_frame = tk.Frame(root, bg="#eef2f7")
legend_frame.pack(pady=15)

tk.Label(
    legend_frame,
    text="Green = Available",
    font=("Arial", 11, "bold"),
    fg="#27ae60",
    bg="#eef2f7"
).grid(row=0, column=0, padx=20)

tk.Label(
    legend_frame,
    text="Red = Occupied",
    font=("Arial", 11, "bold"),
    fg="#e74c3c",
    bg="#eef2f7"
).grid(row=0, column=1, padx=20)

root.mainloop()
